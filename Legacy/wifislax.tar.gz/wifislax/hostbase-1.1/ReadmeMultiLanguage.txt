
~~~~~~~~~~~~~~~~~~ Hostbase project By Koala @ crack-wifi.com @ wifi-libre.com @ kali-linux.fr ~~~~~~~~~~~~~~~~~~~~

slapt-src -u
slapt-src -i rubygem-gtk2
slapt-src -i rubygem-highline

Las paginas tienen que estar en la carpeta /etc  copia todas las carpetas en paginasAQUI a dentro la carpeta /etc
El fichero httpd.conf que esta en este mismo archivo tiene que estar en la carpeta /etc/httpd, copia lo y borra el otro.

Si hay problemo con hostapd actualizar a el nuevo iso de desarollo

____________________________________________________

ES:

El script se tiene que ejecutar en la carpeta /tmp
Entra en la carpeta wifislax y copia la carpeta de hostbase-1.1 a dentro la carpeta /tmp (hay que poner siempre la carpeta de hostbase-1.1 en /tmp)


A dentro /tmp/hostbase-1.1 click derecho, abrir un terminal aqui


Inicia lo asi:
ruby hostbase.rb


--> No olvidas de empezar por el scan de redes para apagar network-manager <--


____________________________________________________

EN/ES/FR the bascis knowledge:


EN: For better performance this script works ONLY with 2 wifi-cards cause it automatise a lot of thing like the encrypted AP with WPS the active DoS tracking the AP channel etc...

ES: Para mas potentia este script ANDA con 2 tarjeta wifi porqué automatisa un monton de cosas: el AP encryptado con el WPS, la DoS que sigue el Ap etc...

FR: Pour une meilleur performance ce script fonctionne SEULEMENT avec 2 cartes wifi, automatisation de la rogue AP et du WPS, de la DoS qui suit l'ap sur son canal etc... c'est mieux ainsi.2 cartes wifi c'est pas de trop et ça coute aps très cher, il faut savoir ce qu'on veut comme compromis, soit avoir une chance de réussir l'attaque soit la foirer.


You need to start with the scan option to stop network-manager and grab network info // Se tiene que empezar por el scan para parar network-manager y tener informacion sobre la red que quieres // On doit toujours commencer par l'option scan pour stopper network-manager et récupérer les infos du réseau voulu.

____________________________________________________

EN/ES/FR good to know:


EN only: if you want to use this script with the fake page of your country you will need to change the filter in check.rb line 54





Date source //  Informaciones completo // Informations complètes:
EN: https://github.com/Koala633/hostbase/blob/master/hostbaseEnglishVersion/RogueAPparty.pdf

FR: http://www.crack-wifi.com/forum/topic-12236-hostbase-11-beta-test.html
FR: https://github.com/Koala633/hostbase/blob/master/hostbase/UnehistoirederogueAP.pdf

ES: # lien wifi libre a mettre hostbase-1.1
ES: https://www.wifi-libre.com/topic-756-una-historia-de-rogue-ap-el-pdf-de-koala-traducido-al-espanol.html

	 














