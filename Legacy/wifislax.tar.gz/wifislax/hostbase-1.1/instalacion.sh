#!/bin/bash


echo -e "\e[1;33m Hostbase wifislax version By Koala alias Flow\e[0m"
echo -e "                        |\          )           (                              "
echo -e "                    ____| \__        )         (                               "
echo -e "                   |       @ \        )       (                                "
echo -e "~~~~~~~~~~~~~~~~~~~|~~<->    /         )     (                                 "
echo -e "                   |_________\          ) | (                                  "
echo -e "                    |    |                |                                    "
echo -e "___________________(|)__(|)_____________  |  __________________________________"
echo -e "\e[1;34m El mejor de airbase y hostapd.\e[0m"
echo
echo -e "\e[1;31m INFORMACION: el script anda con 2 tarjetas y version igual o superior a la del 20/02/2018.\e[0m"
echo





echo -e "\t\e[1;32m [+] Configuracion de los ficheros..."
cp -R /$(pwd)/paginasAQUI/* /etc/
sleep 3
cp httpd.conf /etc/httpd/
echo -e "\e[1;94m[*]\e[0m Verificando compatibilidad con la version avanzada..."
lspci > check.txt
carte="Atheros"
if grep -qF "$carte" check.txt;then
   echo -e "\e[1;94m[*]\e[0m Se tiene una tarjeta Atheros, compatibilidad con la version avanzada: wifislax OK"
else
   echo -e "\e[1;94m[*]\e[0m No se tiene tarjeta Atheros, hay que usar la version facil: wifislaxairbase"
fi
rm -rf check.txt
ip link show > check.txt
name="wlan1"
if grep -qF "$name" check.txt;then
   echo -e "\t\e[1;32m [+] OK: se ha detectado 2 tarjetas wifi y el script necesita 2 para andar"
else
  echo -e "\n\e[1;31m[-]\e[0m ERROR: que sea la version de hostbase facil o avanzada, el script anda con 2 tarjetas, no siguès mas lejos hasta no tener otra tarjeta wifi que sea compatible con el modo monitor y aircrack-ng!\n"
fi
rm -rf check.txt
echo -e "\e[1;94m[*]\e[0m Verificando la version de wifislax..."
uname -a > check.txt
version="4.14.31"
if grep -qF "$version" check.txt;then
   echo -e "\t\e[1;32m [+] OK: tu version de wifislax esta buena para andar con hostbase"
else
  echo -e "\n\e[1;31m[-]\e[0m ERROR: tienes una version antigua de wifislax : NO haces caso a este mensaje si tienes una version de wifislax igual o superior a la del 20/02/2018 \n"
fi
rm -rf check.txt
echo -e "\e[1;94m[*]\e[0m INFORMACION: Si teneis problemo por favor envia la salida de consola de este script en los foros..."


