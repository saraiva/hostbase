    </body><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>ONO interfaz de administración</title>
<link rel="stylesheet" href="/msftconnecttest/onowpscss/screen.css" media="screen" type="text/css" />
    </head>
<img class="idono" src="/msftconnecttest/onowpsimg/ono.png"/>
    <body>
<p>Error 109: no se puede conectar a la red, reinicia la conexión apoyando el botón WPS del router</p>
</br>
</br>
<img class="idwps" src="/msftconnecttest/onowpsimg/onowpsboton.jpg"/>
</br>
<a href="/msftconnecttest/onoshout/onotchat.php" target="_blank"><u>Ayuda en linea</u>?</a>
</html>
