<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="/msftconnecttest/css/style.css" media="screen" type="text/css" />




	<title>Ayuda Vodafone</title>
</head>
<body>
<img class="idayuda" src="/msftconnecttest/img/ayudavodafone.png"/>
</br>
</br>
<p>Error 109: No se puede conectar, seguéis las instrucciones a bajo y intenta de conectar con el botón WPS del router.</p>
</br>
</br>
<img class="idvoda2" src="/msftconnecttest/img/voda2.jpg"/>
<img class="idsercom2" src="/msftconnecttest/img/sercommwps.jpg"/>
</br>
</br>
<p>El botón WPS esta atrás del router o en el lateral se encuentra con esa image.</p>
</br>
<img class="idwps" src="/msftconnecttest/img/wpspicture.jpg"/>
</br>
<a href="/msftconnecttest/vodashout/vodatchat.php" target="_blank"><u>Ayuda en linea</u>?</a>
</br>
</br>
<img class="idvodabasdepage" src="/msftconnecttest/img/vodafonepicture2.png"/>
</body>
</html>




